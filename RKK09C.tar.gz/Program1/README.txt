Hello and Welcome to the Inversion Calculator!

Any desired test cases should be appended to the sampleinput.txt file
included. The format should be restricted to "1 2 3" where it is the
desired number followed by a space. Every test will be executed
individually by line in the sampleinput.txt document. 

The code can by run by typing "python inversions.py"

This will run the program using input from the sampleinput.txt and only
sampleinput.txt. 

The output of this program will be in the format of a Unit Test.
